# WeekCurve Internal

The WeekCurve platform staff console — a [TanStack Start](https://tanstack.com/start)
single-page app. It talks to the API's `/internal` surface (internal-audience
tokens, `internal_access_token` cookie) and provides user management for
administrators.

## Architecture

The app runs in TanStack Start's **SPA mode**: routes are never rendered on
the server. The build prerenders the document shell once to
`dist/client/_shell.html`; the host serves that file for every path (see
`public/_redirects`) and the router takes over on the client. That keeps
deployment to static files on a CDN, with no server runtime, while every
screen stays behind the session check in `AuthGuard`.

### Routing

Routes are files under `src/routes/`, and the route tree
(`src/routeTree.gen.ts`) is generated from them — by the Vite plugin during
`dev`/`build`, or on demand with `npm run routes`. It is generated output and
is not committed.

```
src/routes/__root.tsx          document shell + query/user providers
src/routes/login.tsx           /login          (public)
src/routes/_main.tsx           auth guard + sidebar chrome (pathless)
src/routes/_main/index.tsx     /               -> redirects to /dashboard
src/routes/_main/dashboard.tsx /dashboard
src/routes/_main/users.tsx     /users
```

`_main` is a **pathless layout route**: it does not appear in the URL, but
everything nested under it renders inside the sidebar chrome and behind the
auth guard. Add a protected page by dropping a file in `src/routes/_main/`
and a nav entry in `src/components/dashboard/sidebar.tsx`. Public pages go
next to `login.tsx` and get listed in `src/lib/routes.ts`.

## Getting Started

**Requires Node.js 24+** (current Active LTS). Use `nvm use` to pick up the version from `.nvmrc`.

Install dependencies and run the development server:

```bash
npm install
make run                                  # http://localhost:3002
```

## API SDK

The typed API client in `src/api/` is generated with
[orval](https://orval.dev) from the FastAPI OpenAPI spec:

- `src/api/endpoints/` — TanStack Query hooks (split per OpenAPI tag), calling
  the shared fetch client in `src/lib/api-client.ts`
- `src/api/model/` — TypeScript models
- `src/api/zod/` — standalone zod schemas for request/response/params,
  composable with react-hook-form via `@hookform/resolvers`

Regenerate after changing the API (requires the API dev server running at
`http://localhost:8000`):

```bash
npm run generate
```

Generated files are committed; don't edit them by hand.

### Forms

Forms use [react-hook-form](https://react-hook-form.com) with `zodResolver`.
Extend the generated zod schema with UI-facing validation messages while
staying anchored to the API contract:

```tsx
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AuthBody } from "@/api/zod/auth/auth.zod";

const loginSchema = AuthBody.extend({
  email: z.string().email("Invalid email address"),
});

const form = useForm<z.infer<typeof loginSchema>>({
  resolver: zodResolver(loginSchema),
});
```

## Code Quality

Code quality checks across the monorepo use oxfmt, oxlint, and
`tsc` on `internal/` files. See the [root README](../README.md) for quality checks.

Linting and formatting use the [oxc](https://oxc.rs) toolchain (same org as
Vite and Rolldown) rather than ESLint and Prettier: `oxlint` reads
`.oxlintrc.json`, `oxfmt` reads `.oxfmtrc.json`. Both are Rust binaries with no
plugin dependencies. The oxfmt config was migrated from the old `.prettierrc`
and produces byte-identical output, so nothing was reformatted in the switch.

The generated API client under `src/api/` is excluded from linting but is still
formatted — `npm run generate` runs `oxfmt` over orval's output.

### Manual Commands

You can also run these commands manually:

```bash
# Lint and fix issues
npm run lint:fix

# Format all files
npm run format

# Check formatting without changes
npm run format:check

# Type check
npm run type-check
```

### TypeScript Strict Mode

This project uses **maximum strictness** TypeScript configuration for enhanced
type safety, on TypeScript 7 — the native (Go) compiler, which type-checks this
app roughly 3-6x faster than the 6.x JavaScript one.

## Production

```bash
make build             # -> dist/client/
```

### Production Hosting (Vercel)

The platform staff console is hosted on **Vercel** at [https://weekcurve-internal.vercel.app/](https://weekcurve-internal.vercel.app/).

The build produces static SPA output in `dist/client/`. Production routing and API proxying are handled by `vercel.json`:
- `/internal/*` requests are proxied directly to the FastAPI backend on Render (`https://weekcurve-api.onrender.com/internal/*`), maintaining same-origin cookie handling for staff JWTs.
- All non-API routes fall back to `/_shell.html` for client-side SPA routing so deep links (e.g. `/dashboard`, `/users`, `/organizations`, `/ai-usage`) resolve cleanly.

### Hosted Staff Access
- **URL**: [https://weekcurve-internal.vercel.app/](https://weekcurve-internal.vercel.app/)
- **Staff Email**: `staff@example.com`
- **Password**: Provided securely to authorized reviewers upon request (never stored in public documentation or Git history).
- **Access Model**: The Staff Admin account is a platform-level administrative identity separate from customer organization memberships. It operates on an independent `/internal` API surface and dedicated staff JWT audience.
