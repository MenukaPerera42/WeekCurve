# WeekCurve Site

The WeekCurve landing page — a [TanStack Start](https://tanstack.com/start)
marketing site, statically generated and API-less. Unlike
[`app/`](../app/README.md), there is no orval-generated API client
here; it's just static pages and the full
[shadcn/ui](https://ui.shadcn.com) component library.

The landing page links to the customer app through `VITE_APP_URL`. Set this
to the customer app's public URL before deploying the static site.

## Architecture

Built on the **Jamstack architecture** using TanStack Start's static
prerendering. Every route is rendered to HTML at build time (`prerender` in
`vite.config.ts`), so the site deploys as plain files to a CDN — fast, secure,
and cheap to host. `crawlLinks` follows internal links from rendered pages, so
a new route linked from an existing page is prerendered automatically.

## Getting Started

**Requires Node.js 24+** (current Active LTS). Use `nvm use` to pick up the
version from `.nvmrc`.

```bash
npm install
make run                                  # http://localhost:3000
```

`make run` starts the Vite dev server on port 3000 (the api runs on 8000,
`app/` on 3001, `internal/` on 3002).

## Routing

Routes are files under `src/routes/`, and the route tree
(`src/routeTree.gen.ts`) is generated from them — by the Vite plugin during
`dev`/`build`, or on demand with `npm run routes`. It is generated output and
is not committed.

```
src/routes/__root.tsx    document shell: <html>, <head> meta, stylesheet links
src/routes/index.tsx     /
```

Page metadata lives in a route's `head()` (the equivalent of the Next.js
`metadata` export):

```tsx
export const Route = createFileRoute("/pricing")({
  head: () => ({ meta: [{ title: "Pricing" }] }),
  component: Pricing,
});
```

## Components

The full shadcn/ui library ships under `src/components/ui/`. Import directly:

```tsx
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
```

Add or update components with the shadcn CLI as usual:

```bash
npx shadcn@latest add <component>
```

## Code Quality

Code quality checks across the monorepo use oxfmt, oxlint, and
`tsc` on `site/` files. See the [root README](../README.md) for quality checks.

Linting and formatting use the [oxc](https://oxc.rs) toolchain (same org as
Vite and Rolldown) rather than ESLint and Prettier: `oxlint` reads
`.oxlintrc.json`, `oxfmt` reads `.oxfmtrc.json`. Both are Rust binaries with no
plugin dependencies — a full lint of `site/` runs in ~70ms against ESLint's
~5s. The oxfmt config was migrated from the old `.prettierrc` and produces
byte-identical output, so nothing was reformatted in the switch. `app/`
and `internal/` use the same toolchain.

Run the checks manually:

```bash
npm run lint:fix       # lint and fix
npm run format         # format all files
npm run type-check     # generate routes + tsc --noEmit
npm run validate       # type-check + lint + format:check
```

## Production

```bash
make build             # -> dist/client/
```

### Production Hosting (Vercel)

The marketing website is hosted on **Vercel** at [https://weekcurve-site.vercel.app/](https://weekcurve-site.vercel.app/).

The build produces static prerendered HTML and hashed assets in `dist/client/` (configured in `vercel.json`), deploying as a pure static Jamstack site without server runtime dependencies.
