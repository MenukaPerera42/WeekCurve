import os

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.routing import APIRoute
from fastapi.staticfiles import StaticFiles

from app.api.app.router import router as app_router
from app.api.internal.router import router as internal_router
from app.config import settings
from app.exceptions import APIException


def route_operation_id(route: APIRoute) -> str:
    # Use the endpoint function name as the operationId instead of FastAPI's
    # default "{name}_{path}_{method}". This keeps the generated frontend client
    # readable (e.g. useGetCurrentUser instead of useGetCurrentUserUsersMeGet).
    # Endpoint function names within each sub-app are unique, so no collisions.
    return route.name


# The OpenAPI schema and the interactive docs it powers expose the full API
# surface, so they are served everywhere except production. Passed to every app
# below: the mounted sub-apps serve their own docs, independently of the root.
openapi_url = None if settings.is_production else "/openapi.json"
docs_url = None if settings.is_production else "/docs"
redoc_url = None if settings.is_production else "/redoc"

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url=openapi_url,
    docs_url=docs_url,
    redoc_url=redoc_url,
)


@app.middleware("http")
async def protect_cookie_writes(request: Request, call_next):
    if request.method not in {"GET", "HEAD", "OPTIONS"} and request.url.path.startswith(("/app/", "/internal/")):
        cookie_name = "internal_access_token" if request.url.path.startswith("/internal/") else "access_token"
        if cookie_name in request.cookies and "Access-Token" not in request.headers:
            origin = request.headers.get("origin")
            if origin not in settings.cors_origins_list and origin != str(request.base_url).rstrip("/"):
                return APIException(403, "INVALID_ORIGIN", "Request origin is not allowed").to_response()
    return await call_next(request)

app_api = FastAPI(
    contact={"name": "Chamoda Pandithage", "email": "chamoda@xaventra.com"},
    description="App api endpoints",
    generate_unique_id_function=route_operation_id,
    openapi_tags=[
        {"name": "meta", "description": "Health and service metadata"},
        {"name": "auth", "description": "Authentication and session"},
        {"name": "users", "description": "User endpoints"},
    ],
    openapi_url=openapi_url,
    docs_url=docs_url,
    redoc_url=redoc_url,
)


@app_api.exception_handler(APIException)
async def api_exception_handler(request: Request, exc: APIException):
    return exc.to_response()


app_api.include_router(app_router)
app_api.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/app", app_api, "app")


internal_api = FastAPI(
    contact={"name": "Chamoda Pandithage", "email": "chamoda@xaventra.com"},
    description="Internal api endpoints",
    generate_unique_id_function=route_operation_id,
    openapi_tags=[
        {"name": "meta", "description": "Health and service metadata"},
        {"name": "auth", "description": "Authentication and session"},
        {"name": "users", "description": "User endpoints"},
    ],
    openapi_url=openapi_url,
    docs_url=docs_url,
    redoc_url=redoc_url,
)


@internal_api.exception_handler(APIException)
async def internal_api_exception_handler(request: Request, exc: APIException):
    return exc.to_response()


internal_api.include_router(internal_router)
internal_api.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/internal", internal_api, "internal")


obj_dir = os.path.join(os.getcwd(), "obj")
if os.path.exists(obj_dir):
    app.mount("/obj", StaticFiles(directory="obj"), name="obj")
